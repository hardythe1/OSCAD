#!/usr/bin/python
OSCAD_HOME="/home/ttt/OSCAD"
