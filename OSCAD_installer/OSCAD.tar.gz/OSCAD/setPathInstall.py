#!/usr/bin/python
OSCAD_HOME=set_PATH_to_OSCAD
